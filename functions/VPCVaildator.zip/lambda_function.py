import json
import boto3
import requests
import botocore

def CFTFailedResponse(event, status, message):
    print("Inside CFTFailedResponse")
    print(message)
    data = {}
    data['Subnet1Id'] = "Nil"
    data['Subnet2Id'] = "Nil"
    data['RouteTableId'] = "Nil"
    
    responseBody = {
        'Status': status,
        'Reason': message,
        'PhysicalResourceId': event['ServiceToken'],
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }
	
    headers={
        'content-type':'',
        'content-length':str(len(json.dumps(responseBody)))	 
    }	
    print('Response = ' + json.dumps(responseBody))
    try:	
        req=requests.put(event['ResponseURL'], data=json.dumps(responseBody),headers=headers)
        print("delete_respond_cloudformation res "+str(req))		
    except Exception as e:
        print("Failed to send cf response {}".format(e))
        
def CFTSuccessResponse(event, status, data=None):
    responseBody = {
        'Status': status,
        'Reason': 'See the details in CloudWatch Log Stream',
        'PhysicalResourceId': event['ServiceToken'],
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }
    headers={
        'content-type':'',
        'content-length':str(len(json.dumps(responseBody)))	 
    }	
    print('Response = ' + json.dumps(responseBody))
    #print(event)
    try:	
        req=requests.put(event['ResponseURL'], data=json.dumps(responseBody),headers=headers)
    except Exception as e:
        print("Failed to send cf response {}".format(e))

def modify_vpc(event,client,vpcId):
    try:
        response = client.modify_vpc_attribute(
            EnableDnsHostnames={
                'Value': True
            },
            VpcId=vpcId
        )
        print("DnsHostnames is Enable for VPC -  "+vpcId)
    except Exception as e:
        message = "VPC DnsHostnames error - "+e
        print(message)
        CFTFailedResponse(event, "FAILED", message)
    try:
        response = client.modify_vpc_attribute(
            EnableDnsSupport={
                'Value': True
            },
            VpcId=vpcId
        )
        print("DnsSupport is Enable for VPC -  "+vpcId)
    except Exception as e:
        message = "VPC DnsSupport error - "+e
        print(message)
        CFTFailedResponse(event, "FAILED", message)

def auditVPC(event,client,vpcId):
    response = client.describe_internet_gateways(
        Filters=[
            {
                'Name': 'attachment.vpc-id',
                'Values': [
                    vpcId
                ]
            },
        ]
    )
    if len(response['InternetGateways']) > 0:
        igwId = response['InternetGateways'][0]['InternetGatewayId']
        print("Provided VPC - "+vpcId+" is having internet gateway attached - "+igwId)
        CFTFailedResponse(event, "FAILED", "Provided VPC is exposed to internet gateway.")
        return False
    else:
        print("VPC audit is completed !!!")
        return True

def lambda_handler(event, context):
    print("Event:")
    print(event)
    client = boto3.client('ec2')
    data = {}
    
    if event['RequestType'] == 'Create':
        try:
            ## Value Intialization from CFT ##
            vpcId = event['ResourceProperties']['VPCID']
        except Exception as e:
            message = "VPC Validator parameter Error: "+str(e)
            print(e)
            CFTFailedResponse(event, "FAILED", str(e))
        try:
            ## VPC Audit ##
            status = auditVPC(event,client,vpcId)
        except Exception as e:
            message = "VPC Validation Error: "+str(e)
            print(message)
            CFTFailedResponse(event, "FAILED", message)
            
        if status:
            print("Provided VPC - "+vpcId+" is not having internet gateway attached")
            ## Modify VPC 
            modify_vpc(event,client,vpcId)
            data['Message'] = "VPC is successfully configured."
            CFTSuccessResponse(event, "SUCCESS", data)
        
    if event['RequestType'] == 'Delete':
        print("Delete operation is completed")
        data["Message"] = "Delete operation is completed"
        CFTSuccessResponse(event, "SUCCESS", data)
    
    if  event['RequestType'] == 'Update':
        print("Update operation is not available")
        data["Message"] = "Update operation is not available"
        CFTSuccessResponse(event, "SUCCESS", data)
                
                
                
                
    
